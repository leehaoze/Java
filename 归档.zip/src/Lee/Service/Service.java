package Lee.Service;

import Lee.Dao.Dao;
import Lee.Model.MarkDown_Article;

import java.util.ArrayList;

@org.springframework.stereotype.Service
public class Service {
    private Dao dao = new Dao();

    public ArrayList<MarkDown_Article> getArticle(){
        return dao.getArticle();
    }
}

package Lee.Model;

public class MarkDown_Article {
    public String title_, author_, content_;


    public MarkDown_Article(String title_, String author_, String content_) {
        this.title_ = title_;
        this.author_ = author_;
        this.content_ = content_;
    }

    public String getTitle_() {
        return title_;
    }

    public void setTitle_(String title_) {
        this.title_ = title_;
    }

    public String getAuthor_() {
        return author_;
    }

    public void setAuthor_(String author_) {
        this.author_ = author_;
    }

    public String getContent_() {
        return content_;
    }

    public void setContent_(String content_) {
        this.content_ = content_;
    }

    @Override
    public String toString() {
        return "MarkDown_Article{" +
                "title_='" + title_ + '\'' +
                ", author_='" + author_ + '\'' +
                ", content_='" + content_ + '\'' +
                '}';
    }
}

package Lee.Controller;

import Lee.Model.MarkDown_Article;
import Lee.Service.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

@org.springframework.stereotype.Controller
public class Control {
    private Service service = new Service();

    @RequestMapping("/getArticle")
    @ResponseBody
    public ArrayList<MarkDown_Article> getArticle(){
        return service.getArticle();
    }
}

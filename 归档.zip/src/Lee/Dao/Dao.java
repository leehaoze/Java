package Lee.Dao;

import Lee.Model.MarkDown_Article;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class Dao {
    public ArrayList<MarkDown_Article> getArticle(){
        ArrayList<MarkDown_Article> data = new ArrayList<MarkDown_Article>();
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        data.add(new MarkDown_Article("Title","leehaoze","This is content"));
        return data;
    }
}

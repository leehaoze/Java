// 设定高度
$(window).resize(function () {
    pre();
});

$(document).ready(function () {
   pre();
});

function pre() {
    var header_height = innerHeight * 0.95;
    var menu_height = innerHeight * 0.05;
    if(header_height >= 1080){
        header_height = 1080;//图片的高
    }

    $('#head').css('height',header_height);
    $('#menu').css('height',menu_height);
    $('#container').css('margin-top',header_height);

    var info_padding_top = header_height * 0.45;
    $('#info').css('padding-top',info_padding_top);
};

// 控制视觉差效果
$(document).ready(function () {
    var headerHeight = $('#head').height();

    $(document).scroll(function () {
        var pos = $(document).scrollTop();
        var parallax = parseInt(pos * -0.3) + 'px';
        var rgba = (pos / headerHeight) * 0.5;
        //计算个人信息上移的距离
        $('#info').css('margin-top', parallax);
        //改变灰度值
        $('#head').css('background', 'rgba(0,0,0,' + rgba);

        if($(document).scrollTop() >= headerHeight){
            // $('#menu').css('top',$(document).scrollTop() - headerHeight);
            $('#menu').css('position','fixed');
            $('#menu').css('top','0px');
            $('#display-area').css('position','relative');
            $('#display-area').css('top',$('#menu').height());
        }
        else{
            // $('#menu').css('top',0);
            $('#menu').css('position','relative');
            $('#display-area').css('top', 10);
        }

    });

    function stopScroll() {
        $('#container').animate({marginTop: headerHeight}, 400);
    }

    $(document).on('mousewheel', function (event) {
        if (event.deltaY == 1 && $(document).scrollTop() == '0') {
            $('#container').animate({marginTop: '+=5px'}, 30);
            clearTimeout($.data(this, "scrollCheck"));
            $.data(this, "scrollCheck", setTimeout(stopScroll, 250));
            console.log(event.deltaX, event.deltaY, event.deltaFactor);
        }
    });
});


//加载菜单
$(document).ready(function () {


    var home_status = false, blog_status = false, aboutMe_status = false, myProjct = false;


    $('.menu-item').click(function () {
        $('body').css('overflow','auto');
        if ($(this).attr('id') == 'blog') {
            $.ajax({
                dataType: "json",
                url: "/getArticle.form",
                success: function (data) {
                    $.each(data, function (index, lineData) {
                        writeDataToPage(lineData);
                    });
                }
            });
            $('body').animate({scrollTop: innerHeight * 0.95}, 1000);
        }
    })
});

// $(document).ready(function () {
//     $.ajax({
//         dataType: "json",
//         url: "/getArticle.form",
//         success: function (data) {
//             $.each(data, function (index, lineData) {
//                 writeDataToPage(lineData);
//             });
//         }
//     });
// });
//
function writeDataToPage(lineData) {
    $('#display-area').append('<span class="article_pre">' +
        '<span class="title">'+lineData['title_']+'</span>' +
        '<span class="author">'+lineData['author_']+'</span>' +
        '<span class="content">'+lineData['content_']+'</span></span>');
}